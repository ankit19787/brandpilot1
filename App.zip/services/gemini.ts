import { GoogleGenAI, Type } from "@google/genai";
import { BrandDNA, ContentStrategy } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * PRODUCTION CREDENTIALS
 */
const INSTAGRAM_WA_TOKEN = "EAAM3MBgT7s4BQUqEw1CvKXxMZAkN2JVeiA3I36TrW9Ny0zWpNlFsEFSOeqeu93sCnKZC7c80NXyZBjekpcNaE0xTWJ10fAZCi3cXvnyVl9bmhJxl6ZB3iRiyhjHTkjDa777JNS3HwdaHUdYSFBZCkPw6TQaR9WWZAgVs47OSqT8t8rCwcgXrwIZAg09YewiI1shYYwZDZD";
const FACEBOOK_PRODUCTION_TOKEN = "EAAM3MBgT7s4BQXY6ePMqQisPczrlF2kReWfsaHBHP9yhpdqBvLSXREZCy4w7zCKctZAih1soZCWHRBZCcZCT0HjdfWOOblzZAmj7Tja1ZBoYD6bGrxnQwfcZALPfiyW4JC4NYchXd52WUlwxSrCZAxzFWxTrdx2YDue1VmhqxbtTLZCTZAwZA9cxifNSqLT4EX48fjzZAOhhcdt0ktOUnsNnRR7aqDyt0bXKVOn71VVkUBfHvGeFevgZDZD"

// X (Twitter) Production Credentials (OAuth 1.0a)
const X_API_KEY = "paL3PcGuHlOzelopy3D1wLAIj";
const X_API_SECRET = "PqH5hn2x3W1gCOYCV1JbkHi9sqDDlj8OtkPd6X7Y82ZpvYSRf3";
const X_ACCESS_TOKEN = "1995694849396502528-6W6Scf6DRs8OO79KzWcWwF5A8JVKYk";
const X_ACCESS_SECRET = "7OxBpfVNOsn7wVwGSqnDgxiZsDFGJngrpSFs9mNgsb5d7";

const INSTAGRAM_BUSINESS_ID = "17841478383986099";
const FACEBOOK_PAGE_ID = "767683059766101";

/**
 * RFC 3986 Percent Encoding
 */
function rfc3986Encode(str: string): string {
  return encodeURIComponent(str).replace(/[!*'()]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
}

/**
 * OAuth 1.0a HMAC-SHA1 Signature Generator (Browser Compatible)
 */
async function generateTwitterOAuth1Signature(
  method: string,
  url: string,
  oauthParams: Record<string, string>,
  consumerSecret: string,
  tokenSecret: string
): Promise<string> {
  const paramString = Object.keys(oauthParams)
    .sort()
    .map((k) => `${rfc3986Encode(k)}=${rfc3986Encode(oauthParams[k])}`)
    .join("&");

  const baseString = `${method.toUpperCase()}&${rfc3986Encode(url)}&${rfc3986Encode(paramString)}`;
  const signingKey = `${rfc3986Encode(consumerSecret)}&${rfc3986Encode(tokenSecret)}`;

  const encoder = new TextEncoder();
  const keyData = encoder.encode(signingKey);
  const messageData = encoder.encode(baseString);

  const cryptoKey = await window.crypto.subtle.importKey(
    "raw",
    keyData,
    { name: "HMAC", hash: "SHA-1" },
    false,
    ["sign"]
  );

  const signature = await window.crypto.subtle.sign("HMAC", cryptoKey, messageData);
  return btoa(String.fromCharCode(...new Uint8Array(signature)));
}

export const analyzeBrandDNA = async (pastPosts: string): Promise<BrandDNA> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Analyze these social media posts for Brand DNA: ${pastPosts}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          voice: { type: Type.STRING },
          personality: { type: Type.ARRAY, items: { type: Type.STRING } },
          contentPillars: { type: Type.ARRAY, items: { type: Type.STRING } },
          audienceType: { type: Type.STRING },
          writingStyle: { type: Type.STRING },
        },
        required: ["voice", "personality", "contentPillars", "audienceType", "writingStyle"],
      },
    },
  });
  return JSON.parse(response.text || '{}');
};

export const generateContentStrategy = async (dna: BrandDNA): Promise<ContentStrategy> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Create a 7-day strategy for: ${JSON.stringify(dna)}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          dailyStrategy: { type: Type.STRING },
          platformFocus: { type: Type.ARRAY, items: { type: Type.STRING } },
          suggestedHooks: { type: Type.ARRAY, items: { type: Type.STRING } },
          recommendedMix: {
            type: Type.OBJECT,
            properties: {
              storytelling: { type: Type.NUMBER },
              authority: { type: Type.NUMBER },
              cta: { type: Type.NUMBER },
            },
          },
        },
        required: ["dailyStrategy", "platformFocus", "suggestedHooks", "recommendedMix"],
      },
    },
  });
  return JSON.parse(response.text || '{}');
};

export const generatePost = async (platform: string, topic: string, dna: BrandDNA): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate a ${platform} post about "${topic}". DNA: ${JSON.stringify(dna)}`,
  });
  return response.text || "Generation failed.";
};

export const generateImage = async (topic: string, dna: BrandDNA): Promise<string> => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: { parts: [{ text: `Professional cinematic visual for: ${topic}. Tone: ${dna.voice}.` }] },
  });
  const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
  if (part?.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  throw new Error("No image generated.");
};

export const platformAPI = {
  async publish(platform: string, content: string, onStatus: (status: string) => void, metadata?: { imageUrl?: string }) {
    onStatus(`Preparing ${platform} transmission...`);

    if (platform === 'X (Twitter)') {
      const twitterApiUrl = "https://api.twitter.com/2/tweets";
      const proxyUrl = "/api/twitter/2/tweets";
      onStatus("Calculating OAuth 1.0a HMAC-SHA1 signature...");
      
      const nonce = Array.from(window.crypto.getRandomValues(new Uint8Array(16)))
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("");
      const timestamp = Math.floor(Date.now() / 1000).toString();

      const oauthParams: Record<string, string> = {
        oauth_consumer_key: X_API_KEY,
        oauth_token: X_ACCESS_TOKEN,
        oauth_nonce: nonce,
        oauth_timestamp: timestamp,
        oauth_signature_method: "HMAC-SHA1",
        oauth_version: "1.0",
      };

      const signature = await generateTwitterOAuth1Signature("POST", twitterApiUrl, oauthParams, X_API_SECRET, X_ACCESS_SECRET);
      oauthParams["oauth_signature"] = signature;

      const authHeader = "OAuth " + Object.keys(oauthParams)
        .sort()
        .map((k) => `${rfc3986Encode(k)}="${rfc3986Encode(oauthParams[k])}"`)
        .join(", ");

      onStatus("Sending direct payload to api.twitter.com...");
      try {
        const res = await fetch(proxyUrl, {
          method: "POST",
          headers: {
            "Authorization": authHeader,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ text: content }),
        });

        if (!res.ok) {
          const json = await res.json().catch(() => ({ detail: "Network response was not ok" }));
          throw new Error(json.detail || `X API Error: ${res.status}`);
        }

        const json = await res.json();
        onStatus(`Published successfully! ID: ${json.data.id}`);
        return { status: 201, id: json.data.id, url: `x.com/status/${json.data.id}` };
      } catch (err: any) {
        if (err.message.includes('Failed to fetch')) {
          onStatus("CRITICAL: CORS Block detected. Browser blocked direct request to Twitter.");
          throw new Error("Failed to fetch: Browser blocked the request. This usually requires a server-side proxy or specific browser settings to allow api.twitter.com.");
        }
        onStatus(`Gateway Error: ${err.message}`);
        throw err;
      }
    }

    if (platform === 'Instagram' || platform === 'Facebook') {
      const isInstagram = platform === 'Instagram';
      const token = isInstagram ? INSTAGRAM_WA_TOKEN : FACEBOOK_PRODUCTION_TOKEN;
      const id = isInstagram ? INSTAGRAM_BUSINESS_ID : FACEBOOK_PAGE_ID;
      
      try {
        if (isInstagram) {
          onStatus("Step 1: Creating Instagram Media Container...");
          const res1 = await fetch(`https://graph.facebook.com/v20.0/${id}/media`, {
            method: 'POST',
            body: new URLSearchParams({ image_url: metadata?.imageUrl || "https://picsum.photos/1080/1080", caption: content, access_token: token })
          });
          const data1 = await res1.json();
          if (!res1.ok) throw new Error(data1.error?.message || "Container failed");

          onStatus("Step 2: Publishing to Feed...");
          const res2 = await fetch(`https://graph.facebook.com/v20.0/${id}/media_publish`, {
            method: 'POST',
            body: new URLSearchParams({ creation_id: data1.id, access_token: token })
          });
          const data2 = await res2.json();
          if (!res2.ok) throw new Error(data2.error?.message || "Publish failed");
          
          return { status: 201, id: data2.id, url: `instagram.com/p/${data2.id}` };
        } else {
          onStatus("Publishing to Facebook Page...");
          const res = await fetch(`https://graph.facebook.com/v20.0/${id}/feed`, {
            method: 'POST',
            body: new URLSearchParams({ message: content, access_token: token })
          });
          const data = await res.json();
          if (!res.ok) throw new Error(data.error?.message || "FB Error");
          return { status: 201, id: data.id, url: `facebook.com/${data.id}` };
        }
      } catch (err: any) {
        onStatus(`Meta Gateway Error: ${err.message}`);
        throw err;
      }
    }

    onStatus(`Simulation: Post pushed to ${platform}.`);
    return { status: 201, id: "mock_" + Date.now(), url: "#" };
  }
};

export const publishToPlatform = async (platform: string, content: string, metadata?: { imageUrl?: string }) => {
  return await platformAPI.publish(platform, content, () => {}, metadata);
};

export const getMonetizationPlan = async (dna: BrandDNA, metrics: any): Promise<any> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Monetization ideas for: ${JSON.stringify(dna)}`,
    config: { responseMimeType: "application/json" },
  });
  return JSON.parse(response.text || '[]');
};